<!-- footer -->
<div class="footer" id="footer">
    <!-- <div class="row "> -->
    <div class="col d-flex justify-content-center footer-information">
        <div class="footer-title">
          <div class="footer-title-img">
            <img src="{{URL::asset('assets/Main/images/Logo-Sulsel.png')}}" alt="">
            <img src="{{URL::asset('assets/Main/images/Logo-PLN.png')}}" alt="">
          </div>
          <h1>SIMTARU</h1>
          <h3>Website Resmi Bidang Tata Ruang Dinas Pekerjaan Umum dan Tata Ruang Provinsi Sulawesi Selatan</h3>
        </div>
        <div class="footer-contact">
          <div class="alamat">
            <i class="uil uil-comments"></i>
            <h4><b>Alamat</b></h4>
            <p>Jalan A. Pangerang Pettarani <br> No. 88-90 Makassar</p>
          </div>
          <div class="kontak">
            <i class="uil uil-comments"></i>
            <h4><b>Hubungi Kami</b></h4>
            <p>Jalan A. Pangerang Pettarani <br> No. 88-90 Makassar</p>
          </div>
          
        </div>
        <div class="footer-license">
          <h4><b>Made Possible by</b></h4>
          <p>ABRIADR 2022</p>
          <h4><B>Hak Cipta 2022 @ Bidang Tata Ruang Dinas Pekerjaan Umum Dan Tata Ruang Provinsi Sulawesi Selatan </B></h4>
        </div>
      <!-- </div> -->
    </div>
</div>