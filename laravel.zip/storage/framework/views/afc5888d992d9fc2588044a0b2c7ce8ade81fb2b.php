

<?php $__env->startSection('Main'); ?>
  <nav>
    <div class="col-md-9 nav-child-wrapper">
      <ul class="nav-menu ">
        <li class="links"><a  href="<?php echo e(url('/')); ?>">Home</a></li>
        <li class="links"><a class="active" href="<?php echo e(url('/tata-ruang')); ?>">Tata Ruang</a></li>
        <li class="links"><a href="<?php echo e(url('/regulasi')); ?>">Regulasi</a></li>
        <li class="links"><a href="<?php echo e(url('/publikasi')); ?>">Publikasi</a></li>
        <li class="links"><a href="<?php echo e(url('/tanggapan')); ?>">Tanggapan</a></li>
      </ul>
    </div>
    <div class="col-md-3 button">
      <form action="/pendaftaran" method="GET">
        <?php echo csrf_field(); ?>
        <button>Pendaftaran</button>
      </form>
    </div>
  </nav>
  <div class="main">
    <?php if($datas != null): ?>
      <iframe src="<?php echo e($datas->data()['mapUrl']); ?>" frameborder="0" id="iframe"></iframe>
    <?php else: ?>
      <H1>Not Found</H1>
    <?php endif; ?>
    <div id="filter">
      <form class="row" action="/tata-ruang/detail" method="get">
        <?php echo method_field('get'); ?>
        <?php echo csrf_field(); ?>
          <div class="dropdown">
            <select class="btn btn-secondary" required name="Kota" id="Kota">
              <option disabled selected value="">Pilih Kota</option>
              <option value="Makassar">Makassar</option>
              <option value="Gowa">Gowa</option>
              <option value="Maros">Maros</option>
            </select>
          </div>
          <div class="dropdown">
            <select class="btn btn-secondary" required name="RTR" id="RTR">
              <option disabled selected value="">Pilih RTR</option>
              <option value="RTR Maminasata">RTR Maminasata</option>
              <option value="RTRW Kab/Kota">RTRW Kab/Kota</option>
              <option value="RTDTR Kab/Kota">RTDTR Kab/Kota</option>
            </select>
          </div>
          <button type="submit" class="button">Lihat</button>
        </form>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addonStyle'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/Main/style/index.css')); ?>">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('Main.Layout.MainWebLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Reinhart Soplantila\Documents\Project\TI\laravell\Website-simtaru\resources\views/Main/Page/maps.blade.php ENDPATH**/ ?>