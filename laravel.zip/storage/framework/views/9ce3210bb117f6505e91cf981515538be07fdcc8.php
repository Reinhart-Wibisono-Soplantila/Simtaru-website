<?php $__env->startSection('Main'); ?>
<div class="wrapper-regulasi">
  <nav>
    <div class="col-md-9 nav-child-wrapper">
      <ul class="nav-menu ">
        <li class="links"><a  href="<?php echo e(url('/')); ?>">Home</a></li>
        <li class="links"><a href="<?php echo e(url('/tata-ruang')); ?>">Tata Ruang</a></li>
        <li class="links"><a class="active" href="<?php echo e(url('/regulasi')); ?>">Regulasi</a></li>
        <li class="links"><a href="<?php echo e(url('/publikasi')); ?>">Publikasi</a></li>
        <li class="links"><a href="<?php echo e(url('/tanggapan')); ?>">Tanggapan</a></li>
      </ul>
    </div>
    <div class="col-md-3 button">
      <form action="/pendaftaran" method="GET">
        <?php echo csrf_field(); ?>
        <button>Pendaftaran</button>
      </form>
    </div>
  </nav>


  <section id="hero">
    <div class="text-center hero-content">
      <h1>REGULASI</h1>
    </div>
  </section>
  
  <div id="collapse-parent">
    <section id="pagination">
      <div class="wrapper-pagination">
        <ul>
          <p>
            <li>
              <a data-bs-toggle="collapse" href="#uu-collapse" role="button" aria-expanded="true" aria-controls="uu-collapse" >UU</a></li>
            <li>
              <a data-bs-toggle="collapse" href="#perpres-collapse" role="button" aria-expanded="false" aria-controls="perpres-collapse">PERPRES</a>
            </li>
            <li>
              <a data-bs-toggle="collapse" href="#kepres-collapse" role="button" aria-expanded="true" aria-controls="kepres-collapse" >KEPRES</a>
            </li>
            <li>
              <a data-bs-toggle="collapse" href="#pp-collapse" role="button" aria-expanded="true" aria-controls="pp-collapse" >PP</a>
            </li>
            <li>
              <a data-bs-toggle="collapse" href="#permen-collapse" role="button" aria-expanded="true" aria-controls="permen-collapse">PERMEN</a>
            </li>
            <li>
              <a data-bs-toggle="collapse" href="#perda-collapse" role="button" aria-expanded="true" aria-controls="perda-collapse">PERDA</a>
            </li>
            <li>
              <a data-bs-toggle="collapse" href="#pergub-collapse" role="button" aria-expanded="true" aria-controls="pergub-collapse">PERGUB</a>
            </li>
          </p>
        </ul>
      </div>
    </section>

   

    <section id="content">
      <div id="uu-collapse" class="collapse show" data-bs-parent="#collapse-parent">
        <div class="wrapper-content">
          <div class="cards">
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($item->data()['kategori'] == 'Undang-Undang'): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-2 file-logo">
                  <img src="<?php echo e(URL::asset('assets/Main/images/pdf.png')); ?>" alt="">
                </div>
                <div class="col-lg-10 file-element">
                  <h5><?php echo e($item->data()['judul']); ?></h5>
                  
                  <div class="button">
                    <a href="<?php echo e($item->data()['link']); ?>"><button type="button">Download</button></a>
                  </div>
                </div>
              </div>
              <!-- divider between two cards-->
              <br>
              <?php else: ?>
                <?php $empty = True ?>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                Maaf, sepertinya data yang anda cari tidak ada
            <?php endif; ?>

            
                    
          </div>
        </div>
      </div>

      <!-- PERPRES -->
      <div id="perpres-collapse" class="collapse" data-bs-parent="#collapse-parent">
        <div class="wrapper-content">
          <div class="cards"> 
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($item->data()['kategori'] == 'Peraturan Presiden'): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-2 file-logo">
                  <img src="<?php echo e(URL::asset('assets/Main/images/pdf.png')); ?>" alt="">
                </div>
                <div class="col-lg-10 file-element">
                  <h5><?php echo e($item->data()['judul']); ?></h5>
                  
                  <div class="button">
                    <a href="<?php echo e($item->data()['link']); ?>"><button type="button">Download</button></a>
                  </div>
                </div>
              </div>
              <!-- divider between two cards-->
              <br>
              <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-10 file-element">
                  <h5> Maaf, sepertinya data yang anda cari tidak ada</h5>
                </div>
              </div>
            <?php endif; ?>
                    
          </div>
        </div>
      </div>

      <!-- KEPRES -->
      <div id="kepres-collapse" class="collapse" data-bs-parent="#collapse-parent">
        <div class="wrapper-content">
          <div class="cards"> 
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($item->data()['kategori'] == 'Keputusan Presiden'): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-2 file-logo">
                  <img src="<?php echo e(URL::asset('assets/Main/images/pdf.png')); ?>" alt="">
                </div>
                <div class="col-lg-10 file-element">
                  <h5><?php echo e($item->data()['judul']); ?></h5>
                  
                  <div class="button">
                    <a href="<?php echo e($item->data()['link']); ?>"><button type="button">Download</button></a>
                  </div>
                </div>
              </div>
              <!-- divider between two cards-->
              <br>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-10 file-element">
                  <h5> Maaf, sepertinya data yang anda cari tidak ada</h5>
                </div>
              </div>
            <?php endif; ?>
                    
          </div>
        </div>
      </div>

      <!-- PP -->
      <div id="pp-collapse" class="collapse" data-bs-parent="#collapse-parent">
        <div class="wrapper-content">
          <div class="cards"> 
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($item->data()['kategori'] == 'Peraturan Pemerintah'): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-2 file-logo">
                  <img src="<?php echo e(URL::asset('assets/Main/images/pdf.png')); ?>" alt="">
                </div>
                <div class="col-lg-10 file-element">
                  <h5><?php echo e($item->data()['judul']); ?></h5>
                  
                  <div class="button">
                    <a href="<?php echo e($item->data()['link']); ?>"><button type="button">Download</button></a>
                  </div>
                </div>
              </div>
              <!-- divider between two cards-->
              <br>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-10 file-element">
                  <h5> Maaf, sepertinya data yang anda cari tidak ada</h5>
                </div>
              </div>
            <?php endif; ?>
                    
          </div>
        </div>
      </div>

      <!-- PERMEN -->
      <div id="permen-collapse" class="collapse" data-bs-parent="#collapse-parent">
        <div class="wrapper-content">
          <div class="cards"> 
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($item->data()['kategori'] == 'Peraturan Menteri'): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-2 file-logo">
                  <img src="<?php echo e(URL::asset('assets/Main/images/pdf.png')); ?>" alt="">
                </div>
                <div class="col-lg-10 file-element">
                  <h5><?php echo e($item->data()['judul']); ?></h5>
                  
                  <div class="button">
                    <a href="<?php echo e($item->data()['link']); ?>"><button type="button">Download</button></a>
                  </div>
                </div>
              </div>
              <!-- divider between two cards-->
              <br>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-10 file-element">
                  <h5> Maaf, sepertinya data yang anda cari tidak ada</h5>
                </div>
              </div>
            <?php endif; ?>
                    
          </div>
        </div>
      </div>

      <!-- PERDA -->
      <div id="perda-collapse" class="collapse" data-bs-parent="#collapse-parent">
        <div class="wrapper-content">
          <div class="cards"> 
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($item->data()['kategori'] == 'Peraturan Daerah'): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-2 file-logo">
                  <img src="<?php echo e(URL::asset('assets/Main/images/pdf.png')); ?>" alt="">
                </div>
                <div class="col-lg-10 file-element">
                  <h5><?php echo e($item->data()['judul']); ?></h5>
                  
                  <div class="button">
                    <a href="<?php echo e($item->data()['link']); ?>"><button type="button">Download</button></a>
                  </div>
                </div>
              </div>
              <!-- divider between two cards-->
              <br>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-10 file-element">
                  <h5> Maaf, sepertinya data yang anda cari tidak ada</h5>
                </div>
              </div>
            <?php endif; ?>
                    
          </div>
        </div>
      </div>

      <!-- PERGUB -->
      <div id="pergub-collapse" class="collapse" data-bs-parent="#collapse-parent">
        <div class="wrapper-content">
          <div class="cards"> 
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($item->data()['kategori'] == 'Peraturan Bupati'): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-2 file-logo">
                  <img src="<?php echo e(URL::asset('assets/Main/images/pdf.png')); ?>" alt="">
                </div>
                <div class="col-lg-10 file-element">
                  <h5><?php echo e($item->data()['judul']); ?></h5>
                  
                  <div class="button">
                    <a href="<?php echo e($item->data()['link']); ?>"><button type="button">Download</button></a>
                  </div>
                </div>
              </div>
              <!-- divider between two cards-->
              <br>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="wrapper-undang2 row">
                <div class="col-lg-10 file-element">
                  <h5> Maaf, sepertinya data yang anda cari tidak ada</h5>
                </div>
              </div>
            <?php endif; ?>
                    
          </div>
        </div>
      </div>

    </section>

  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addonStyle'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/Main/style/regulasi.css')); ?>">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('Main.Layout.MainWebLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Reinhart Soplantila\Documents\Project\TI\laravell\Website-simtaru\resources\views/Main/Page/regulasi.blade.php ENDPATH**/ ?>