    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(URL::asset('/assets/CMS/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/CMS/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(URL::asset('/assets/CMS/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(URL::asset('/assets/CMS/js/sb-admin-2.min.js')); ?>"></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(URL::asset('/assets/CMS/vendor/chart.js/Chart.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(URL::asset('/assets/CMS/js/demo/chart-area-demo.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/CMS/js/demo/chart-pie-demo.js')); ?>"></script>
    <?php /**PATH C:\Users\Reinhart Soplantila\Documents\Project\TI\laravell\Website-simtaru\resources\views/CMS/Include/Script.blade.php ENDPATH**/ ?>