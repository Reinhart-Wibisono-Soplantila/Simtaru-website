<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php echo $__env->yieldPushContent('addonHead'); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->make('Main.Include.Style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('addonStyle'); ?>
    <title>SIMTARU</title>
    
    <title>Document</title>
</head>

<body>
    <?php echo $__env->yieldContent('Main'); ?>
    <?php echo $__env->make('Main.Include.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Main.Include.Script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('addonScript'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Reinhart Soplantila\Documents\Project\TI\laravell\Website-simtaru\resources\views/Main/Layout/MainWebLayout.blade.php ENDPATH**/ ?>