<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Login</title>
    <?php echo $__env->make('CMS.Include.Style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="bg-gradient-primary">

    <?php echo $__env->yieldContent('main'); ?>
    <?php echo $__env->make('CMS.Include.Script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\Users\Reinhart Soplantila\Documents\Project\TI\laravell\Website-simtaru\resources\views/CMS/Layout/Login_Layout.blade.php ENDPATH**/ ?>